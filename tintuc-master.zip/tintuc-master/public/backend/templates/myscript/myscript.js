$(document).ready(function () {
   $('.result_msg').delay(4000).slideUp();
});