@extends('backend.master')
@section('title', 'Thêm chủ đề tin tức')
@section('top', 'Thêm chủ đề tin tức')
@section('main')
	<form action="{!! route('admin.cate.getAdd') !!}" method="POST" style="width: 650px;">
		@csrf
		<fieldset>
			<legend>Thông Tin Danh Mục</legend>
			<span class="form_label">Danh mục cha:</span>
			<span class="form_item">
				<select name="sltCate" class="select">
					<option value="0">--- Chọn chủ đề ---</option>
					<?php menuMulti($data, 0, "--", old('sltCate')); ?>
				</select>
			</span><br />
			<span class="form_label">Tên danh mục:</span>
			<span class="form_item">
				<input type="text" name="txtCateName" class="textbox" value="{!! old('txtCateName') !!}"/>
			</span><br />
			<span class="form_label"></span>
			<span class="form_item">
				<input type="submit" name="btnCateAdd" value="Thêm danh mục" class="button" />
			</span>
		</fieldset>
	</form>
@endsection